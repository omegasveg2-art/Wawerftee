#include "game.h"
#include <chrono>
#include <cstring>
#include <unordered_map>

static double now_s() {
    using namespace std::chrono;
    return duration<double>(steady_clock::now().time_since_epoch()).count();
}

static bool finite3(Vec3 v) { return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z); }

bool Game::resolve() {
    if (!kCull_) kCull_ = il_.klass(off::PlayerCulling::cls);
    if (!kFps_)  kFps_  = il_.klass(off::PlayerFPSCamera::cls);
    if (!kLife_) kLife_ = il_.klass(off::LifeState::cls);
    cullStatics_ = il_.statics(kCull_);
    fpsStatics_  = il_.statics(kFps_);
    status_ = !kCull_ ? "no PlayerCulling class" : !cullStatics_ ? "PlayerCulling statics null (cctor not run)" : "ok";
    return kCull_ && cullStatics_;
}

// LifeState has no static handle we can reach from a klass slot (it hangs off the PlayerLife singleton),
// so locate the instance by scanning for objects whose first word is the LifeState klass.
bool Game::find_life() {
    if (!kLife_) return false;
    auto valid = [&](uint64_t o) {
        uint64_t items; uint32_t n;
        if (rdp(m_, o) != kLife_) return false;
        if (!il_.list(rdp(m_, o + off::LifeState::_entries), items, n, 64)) return false;
        return n > 0;
    };
    uint64_t best = 0; uint32_t bestN = 0;
    for (uint64_t o : il_.find_instances(kLife_, valid)) {
        uint64_t items; uint32_t n;
        il_.list(rdp(m_, o + off::LifeState::_entries), items, n, 64);
        if (n >= bestN) { best = o; bestN = n; }
    }
    life_ = best;
    return life_ != 0;
}

bool Game::update(Snapshot& s) {
    s.valid = false; s.haveLocal = false; s.localActor = 0; s.localTeam = 0; s.lifeOk = false;
    s.players.clear();
    if (!cullStatics_ && !resolve()) return false;

    // --- camera (statics of PlayerCulling are refreshed by the game every frame)
    Vec3 pos = rdv<Vec3>(m_, cullStatics_ + off::PlayerCulling::s__cameraPosition);
    Vec3 fwd = rdv<Vec3>(m_, cullStatics_ + off::PlayerCulling::s__cameraForward);
    bool hasCam = rd8(m_, cullStatics_ + off::PlayerCulling::s__hasCamera) != 0;
    float fl = len(fwd);
    if (!hasCam || !finite3(pos) || !finite3(fwd) || fl < 0.9f || fl > 1.1f) { status_ = "no camera"; return false; }
    s.cam.pos = pos; s.cam.fwd = fwd;
    float fov = 0;
    if (fpsStatics_) {
        uint64_t loc = rdp(m_, fpsStatics_ + off::PlayerFPSCamera::s_Local);
        if (plausible_ptr(loc)) fov = rdf(m_, loc + off::PlayerFPSCamera::BaseFieldOfView);
    }
    s.cam.fovY = (fov > 20.f && fov < 140.f) ? fov : 60.f;

    // --- players
    uint64_t items; uint32_t n;
    if (!il_.list(rdp(m_, cullStatics_ + off::PlayerCulling::s_Instances), items, n, 64)) { status_ = "bad Instances"; return false; }
    uint64_t ptrs[64] = {0};
    if (n && !m_.read(items + il2::ARR_DATA, ptrs, n * 8)) { status_ = "bad Instances array"; return false; }

    // --- hp/team table: actor -> LifeEntry
    std::unordered_map<int, std::pair<int, uint8_t>> life;   // hp, team (+alive folded into hp<=0)
    s.lifeOk = false;
    if (kLife_) {
        uint64_t litems; uint32_t ln;
        bool ok = life_ && rdp(m_, life_) == kLife_ && il_.list(rdp(m_, life_ + off::LifeState::_entries), litems, ln, 64);
        if (!ok && n > 0 && now_s() >= nextLifeScan_) { find_life(); nextLifeScan_ = now_s() + 5.0; }   // heap scan: only in a match, throttled
        if (life_ && rdp(m_, life_) == kLife_ && il_.list(rdp(m_, life_ + off::LifeState::_entries), litems, ln, 64) && ln) {
            std::vector<uint8_t> raw((size_t)ln * off::LifeEntrySize);
            if (m_.read(litems + il2::ARR_DATA, raw.data(), raw.size())) {
                for (uint32_t i = 0; i < ln; i++) {
                    const uint8_t* e = &raw[(size_t)i * off::LifeEntrySize];
                    int actor, hp;
                    memcpy(&actor, e + off::LifeEntry::Actor, 4);
                    memcpy(&hp, e + off::LifeEntry::Health, 4);
                    bool alive = e[off::LifeEntry::Alive] != 0;
                    life[actor] = {alive ? hp : 0, e[off::LifeEntry::Team]};
                }
                s.lifeOk = true;
            }
        }
    }

    for (uint32_t i = 0; i < n; i++) {
        uint64_t cull = untag(ptrs[i]);
        if (!plausible_ptr(cull)) continue;
        uint64_t ctrl = rdp(m_, cull + off::PlayerCulling::_controller);
        uint64_t net  = rdp(m_, cull + off::PlayerCulling::_network);
        if (!plausible_ptr(ctrl) || !plausible_ptr(net)) continue;
        uint64_t view = rdp(m_, ctrl + off::PlayerController::_view);
        if (!plausible_ptr(view)) continue;

        PlayerInfo p;
        p.local = rd8(m_, view + off::PhotonView::IsMine) != 0;
        p.actor = (int)rd32(m_, view + off::PhotonView::ownerActorNr);
        p.dead  = rd8(m_, ctrl + off::PlayerController::_isDeath) != 0;
        p.pos   = rdv<Vec3>(m_, net + off::PlayerNetwork::networkPosition);
        p.vel   = rdv<Vec3>(m_, net + off::PlayerNetwork::_remoteVelocity);
        {
            float q[4];                                   // networkRotation (x,y,z,w) -> yaw
            if (m_.read(net + off::PlayerNetwork::networkRotation, q, sizeof q) && std::isfinite(q[0]) && std::isfinite(q[1]) && std::isfinite(q[2]) && std::isfinite(q[3]))
                p.yaw = std::atan2(2.f * (q[3] * q[1] + q[0] * q[2]), 1.f - 2.f * (q[1] * q[1] + q[2] * q[2])) * 57.29578f;
        }
        p.crouch = (rd8(m_, net + off::PlayerNetwork::_appliedBools) & 2) != 0;   // PlayerNetwork.BoolCrouching
        uint64_t pl = rdp(m_, ctrl + off::PlayerController::_player);
        if (plausible_ptr(pl)) {
            std::string nm = il_.str(rdp(m_, pl + off::Player::nickName));
            strncpy(p.name, nm.c_str(), sizeof p.name - 1);
        }
        auto it = life.find(p.actor);
        if (it != life.end()) {
            p.hp = it->second.first;
            p.team = it->second.second;
            if (p.hp <= 0) p.dead = true;
        }
        if (!finite3(p.pos) || (p.pos.x == 0 && p.pos.y == 0 && p.pos.z == 0)) continue;   // not spawned yet
        if (p.local) { s.haveLocal = true; s.localActor = p.actor; s.localTeam = p.team; }
        s.players.push_back(p);
    }
    s.valid = true;
    status_ = "ok";
    return true;
}

// ---- weapon mods: zero a few managed floats of the (shared) weapon parameter objects, restore the originals when switched off
void Game::patch_weapons(bool noRecoil, bool noSpread) {
    const double t = now_s();
    if (t < nextWp_) return;
    nextWp_ = t + 1.0;
    if (!noRecoil && !noSpread && saved_.empty()) return;

    auto restore = [&](int cat) {
        for (size_t i = 0; i < saved_.size();) {
            if (saved_[i].cat == cat) { m_.write(saved_[i].addr, &saved_[i].bits, 4); saved_.erase(saved_.begin() + i); }
            else i++;
        }
    };
    if (!noRecoil) restore(1);
    if (!noSpread) restore(2);
    if (!noRecoil && !noSpread) return;

    // (re)find the WeaponParameters objects: once, and again when they vanished
    bool stale = wp_.empty();
    for (uint64_t o : wp_) if (rdp(m_, o) != kWp_) { stale = true; break; }
    if (stale && t >= nextWpScan_) {
        nextWpScan_ = t + 15.0;
        if (!kWp_) kWp_ = il_.klass(off::WeaponParameters::cls);
        wp_.clear();
        if (kWp_)
            wp_ = il_.find_instances(kWp_, [&](uint64_t o) { return plausible_ptr(rdp(m_, o + off::WeaponParameters::_recoilParameters)); });
    }
    auto zero = [&](uint64_t addr, int cat) {
        uint32_t cur = rd32(m_, addr);
        float f; memcpy(&f, &cur, 4);
        if (!std::isfinite(f) || f == 0.f) return;               // already zero (or garbage): nothing to do / nothing to save
        for (auto& s : saved_) if (s.addr == addr) return;
        uint32_t z = 0;
        if (m_.write(addr, &z, 4)) saved_.push_back({addr, cur, cat});
    };
    for (uint64_t o : wp_) {
        if (rdp(m_, o) != kWp_) continue;
        if (noSpread) { zero(o + off::WeaponParameters::_pelletSpread, 2); zero(o + off::WeaponParameters::_scopedMoveInaccuracy, 2); }
        if (noRecoil) {
            uint64_t rp = rdp(m_, o + off::WeaponParameters::_recoilParameters);
            if (!plausible_ptr(rp)) continue;
            zero(rp + off::RecoilParameters::_horizontalRange, 1); zero(rp + off::RecoilParameters::_verticalRange, 1);
            zero(rp + off::RecoilParameters::cameraDeviationCoeff, 1); zero(rp + off::RecoilParameters::_viewKickAngle, 1);
        }
    }
}
