#include "il2cpp.h"
#include <cstring>
#include <algorithm>

std::string Il2::cstr(uint64_t a, size_t max) {
    char buf[128] = {0};
    if (max > 127) max = 127;
    if (!plausible_ptr(a)) return {};
    // may straddle into an unmapped page: retry shorter
    for (size_t n = max; n >= 8; n /= 2)
        if (m_.read(a, buf, n)) { buf[n] = 0; return std::string(buf); }
    return {};
}

std::string Il2::str(uint64_t s, size_t maxchars) {
    std::string out;
    if (!plausible_ptr(s)) return out;
    uint32_t len = rd32(m_, s + il2::STR_LEN);
    if (len == 0 || len > 256) return out;
    len = (uint32_t)std::min<size_t>(len, maxchars);
    uint16_t w[64] = {0};
    if (!m_.read(s + il2::STR_CHARS, w, len * 2)) return out;
    for (uint32_t i = 0; i < len; i++) out.push_back(w[i] >= 32 && w[i] < 127 ? (char)w[i] : '?');
    return out;
}

bool Il2::list(uint64_t l, uint64_t& items, uint32_t& size, uint32_t maxsize) {
    if (!plausible_ptr(l)) return false;
    items = rdp(m_, l + il2::LIST_ITEMS);
    size = rd32(m_, l + il2::LIST_SIZE);
    if (size > maxsize) return false;
    if (size && !plausible_ptr(items)) return false;
    if (size && rd32(m_, items + il2::ARR_LEN) < size) return false;
    return true;
}

bool Il2::klass_ok(uint64_t k, const ClassRef& c) {
    if (!plausible_ptr(k)) return false;
    if (rdp(m_, k + il2::K_SELF) != k) return false;                // Il2CppClass::klass points to itself
    if (cstr(rdp(m_, k + il2::K_NAME)) != c.name) return false;
    return cstr(rdp(m_, k + il2::K_NS)) == c.ns;
}

uint64_t Il2::klass(const ClassRef& c) {
    if (c.typeinfo_rva) {
        uint64_t k = rdp(m_, base_ + c.typeinfo_rva);
        if (klass_ok(k, c)) return k;
    }
    return scan_klass(c);   // patch moved the slot / slot not filled yet
}

// name scan: find "\0Name\0" in the metadata mapping, then the Il2CppClass whose name ptr == that address
uint64_t Il2::scan_klass(const ClassRef& c) {
    std::string needle = std::string("\0", 1) + c.name + std::string("\0", 1);
    std::vector<uint64_t> names;
    auto regs = m_.regions();
    std::vector<uint8_t> buf;
    for (auto& r : regs) {
        if (!r.r || r.path.find("global-metadata") == std::string::npos) continue;
        for (uint64_t a = r.start; a < r.end; a += 4u << 20) {
            size_t n = (size_t)std::min<uint64_t>(r.end - a, (4u << 20) + needle.size());
            buf.resize(n);
            if (!m_.read(a, buf.data(), n)) continue;
            for (size_t i = 0; (i = std::search(buf.begin() + i, buf.end(), needle.begin(), needle.end()) - buf.begin()) < n; i++) {
                if (a + i + 1 + needle.size() - 2 > r.end) break;
                names.push_back(a + i + 1);
            }
        }
    }
    if (names.empty()) return 0;
    std::sort(names.begin(), names.end());
    names.erase(std::unique(names.begin(), names.end()), names.end());
    for (auto& r : regs) {
        if (!r.r || !r.w) continue;
        if (!r.path.empty() && r.path[0] != '[') continue;          // anon / [heap] / [anon:...] only
        if (r.end - r.start > (512ull << 20)) continue;
        for (uint64_t a = r.start; a < r.end; a += 4u << 20) {
            size_t n = (size_t)std::min<uint64_t>(r.end - a, 4u << 20);
            buf.resize(n);
            if (!m_.read(a, buf.data(), n)) continue;
            for (size_t i = 0; i + 8 <= n; i += 8) {
                uint64_t v;
                memcpy(&v, &buf[i], 8);
                v = untag(v);
                if (!std::binary_search(names.begin(), names.end(), v)) continue;
                uint64_t k = a + i - il2::K_NAME;
                if (k >= r.start && klass_ok(k, c)) return k;
            }
        }
    }
    return 0;
}

std::vector<uint64_t> Il2::find_instances(uint64_t klass, const std::function<bool(uint64_t)>& accept) {
    std::vector<uint64_t> out;
    std::vector<uint8_t> buf;
    for (auto& r : m_.regions()) {
        if (!r.r || !r.w) continue;
        if (!r.path.empty() && r.path[0] != '[') continue;
        if (r.end - r.start > (1024ull << 20)) continue;
        for (uint64_t a = r.start; a < r.end; a += 4u << 20) {
            size_t n = (size_t)std::min<uint64_t>(r.end - a, 4u << 20);
            buf.resize(n);
            if (!m_.read(a, buf.data(), n)) continue;
            for (size_t i = 0; i + 8 <= n; i += 8) {
                uint64_t v;
                memcpy(&v, &buf[i], 8);
                if (untag(v) == klass && accept(a + i)) out.push_back(a + i);
            }
        }
    }
    return out;
}
