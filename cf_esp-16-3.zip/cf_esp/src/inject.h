// root-only evdev helpers: virtual touch finger (aim) + hardware key watcher (aim key). Linux-generic, not device-tested.
#pragma once
#include <vector>

class Touch {
public:
    bool init();                                             // virtual uinput touchscreen first, else writes into the real panel
    const char* mode() const { return ufd_ >= 0 ? "uinput" : fd_ >= 0 ? "panel" : "none"; }
    bool ready() const { return ufd_ >= 0 || fd_ >= 0; }
    void move(float lx, float ly, float W, float H, int rot); // logical px -> raw, (re)starts the finger
    void lift();
    bool active() const { return down_; }
    ~Touch();
private:
    void emit(int type, int code, int value);
    int ufd_ = -1;
    int fd_ = -1, minx_ = 0, maxx_ = 0, miny_ = 0, maxy_ = 0, slot_ = 0, idMax_ = 65535, tid_ = 0;
    bool down_ = false;
};

class Keys {
public:
    bool init();                 // finds devices that report volume keys
    void poll();                 // non-blocking drain
    bool down(int linuxKeyCode) const;
    void grab(bool on);          // swallow the keys system-wide while aiming is bound to them
    ~Keys();
private:
    std::vector<int> fds_;
    bool dn_[2] = {false, false};   // [0] vol down (114), [1] vol up (115)
    bool grabbed_ = false;
};
