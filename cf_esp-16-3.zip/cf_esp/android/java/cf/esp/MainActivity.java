package cf.esp;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private Button btn(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onCreate(Bundle st) {
        super.onCreate(st);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(16), dp(16), dp(16));
        TextView info = new TextView(this);
        info.setText("Wawer\nroot нужен (Magisk/KernelSU). Порядок: 1) разрешить оверлей, 2) зайти в матч, 3) старт. Квадратная кнопка W на экране открывает меню.");
        l.addView(info);
        l.addView(btn("1. разрешить оверлей", v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())))));
        l.addView(btn("2. старт", v -> {
            if (!Settings.canDrawOverlays(this)) { Toast.makeText(this, "сначала разреши оверлей (кнопка 1)", Toast.LENGTH_LONG).show(); return; }
            Intent i = new Intent(this, EspService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            Toast.makeText(this, "запущено, смотри статус внизу слева в игре", Toast.LENGTH_LONG).show();
        }));
        l.addView(btn("стоп", v -> stopService(new Intent(this, EspService.class))));
        setContentView(l);
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
    }
}
